<?php
/**
 * Performance Metrics API
 * Returns current system performance data
 */

header('Content-Type: application/json');

require_once '../db.php';

$metrics = [];

// Database metrics
try {
    $start = microtime(true);
    $stmt = $pdo->query("SELECT COUNT(*) FROM customers");
    $metrics['db_response_time'] = (microtime(true) - $start) * 1000; // ms
    
    // Get last clustering time from logs if available
    $stmt = $pdo->query("SELECT MAX(last_updated) FROM cluster_metadata");
    $lastRun = $stmt->fetchColumn();
    $metrics['last_clustering_timestamp'] = $lastRun;
    
} catch (PDOException $e) {
    $metrics['db_error'] = $e->getMessage();
}

// PHP metrics
$metrics['memory_usage'] = memory_get_usage() / 1024 / 1024; // MB
$metrics['memory_peak'] = memory_get_peak_usage() / 1024 / 1024; // MB
$metrics['php_version'] = phpversion();

// Dummy metrics (replace with actual tracking)
$metrics['avg_response_time'] = rand(50, 200); // ms
$metrics['avg_db_queries'] = rand(3, 8);
$metrics['last_clustering_time'] = 5.23; // seconds

echo json_encode($metrics);
?>